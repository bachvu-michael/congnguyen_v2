CKEDITOR.plugins.setLang( 'imagepicker', 'en', {
	title: 'Image picker',
	toolbar: 'Image picker'
} );