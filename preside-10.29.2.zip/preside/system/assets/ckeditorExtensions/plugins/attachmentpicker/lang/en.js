CKEDITOR.plugins.setLang( 'attachmentpicker', 'en', {
	title: 'Attachment picker',
	toolbar: 'Attachment picker'
} );